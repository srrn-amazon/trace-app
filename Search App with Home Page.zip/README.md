
  # Search App with Home Page

  This is a code bundle for Search App with Home Page. The original project is available at https://www.figma.com/design/VHgjYvd53srCfOZi4v40D7/Search-App-with-Home-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  